loadstring(game:HttpGet("https://paste.ee/r/TCVT4",true))()




--key:TheBestFreeHubEver