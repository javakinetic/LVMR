loadstring(game:GetObjects("rbxassetid://4001118261")[1].Source)()

--

loadstring(game:HttpGet("https://raw.githubusercontent.com/MarsQQ/ScriptHubScripts/master/MM2%20Admin%20Panel"))();