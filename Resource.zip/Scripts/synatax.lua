+ loadstring(game:HttpGet(('https://raw.githubusercontent.com/Vallater/SyntaxFE/main/README.txt'),true))()


key:Syntaxbesthub
key:Syntaxbesthub